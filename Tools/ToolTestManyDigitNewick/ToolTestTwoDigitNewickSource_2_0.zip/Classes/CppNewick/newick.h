//---------------------------------------------------------------------------
/*
BinaryNewickVector, class to store a Newick as a std::vector<int>
Copyright (C) 2010-2011 Richel Bilderbeek

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.If not, see <http://www.gnu.org/licenses/>.
*/
//---------------------------------------------------------------------------
//From http://www.richelbilderbeek.nl/CppBinaryNewickVector.htm
//---------------------------------------------------------------------------
#ifndef NEWICK_H
#define NEWICK_H
//---------------------------------------------------------------------------
#include <string>
#include <vector>
#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>

//---------------------------------------------------------------------------
#include "BigIntegerLibrary.hh"
#include "newickstorage.h"
#include "trace.h"
//---------------------------------------------------------------------------
///namespace Newick contains general Newick functions,
///not using an Newick class
namespace Newick
{
  enum { bracket_open  = -1 };
  enum { bracket_close = -2 };
  enum { comma         = -3 };
  enum { new_line      = -4 };
  enum { null          = -5 };

  ///fuzzy_equal_to is a predicate to test two doubles for equality
  ///with a certain tolerance. A tolerance of 0.0 denotes that
  ///an exact match is requested. Note that the value of 0.0 cannot
  ///be compared fuzzily.
  //From http://www.richelbilderbeek.nl/CppFuzzy_equal_to.htm
  struct fuzzy_equal_to : public std::binary_function<double,double,bool>
  {
    fuzzy_equal_to(const double tolerance = 0.01)
      : m_tolerance(tolerance)
    {
      assert(tolerance >= 0.0);
    }
    bool operator()(const double lhs, const double rhs) const
    {
      return rhs > (1.0 - m_tolerance) * lhs
          && rhs < (1.0 + m_tolerance) * lhs;
    }
    const double m_tolerance;
  };
  //---------------------------------------------------------------------------
  ///CreateVector creates a std::vector from three arguments
  ///From http://www.richelbilderbeek.nl/CppCreateVector.htm
  template <class T>
  const std::vector<T> CreateVector(const T& a, const T& b, const T& c)
  {
    std::vector<T> v;
    v.reserve(3);
    v.push_back(a);
    v.push_back(b);
    v.push_back(c);
    return v;
  }
  //---------------------------------------------------------------------------
  const BigInteger CalcComplexity(const std::vector<int>& v);
  //#ifndef WIN32
  //const cln::cl_I CalcComplexityCln(const std::vector<int>& v);
  //const cln::cl_I CalcNumOfCombinationsCln(const std::vector<int>& v);
  //const std::string CliToStr(const cln::cl_I& i);
  //#endif
  const BigInteger CalcNumOfCombinationsBinary(const std::vector<int>& v);
  const BigInteger CalcNumOfSymmetriesBinary(std::vector<int> v);
  double CalcDenominator(const std::vector<int>& v,const double theta);
  double CalcProbabilitySimpleNewick(const std::vector<int>& v,const double theta);
  void CheckNewick(const std::string& s);
  void CheckNewick(const std::vector<int>& v);
  const std::vector<std::string> CreateInvalidNewicks();
  const std::string CreateRandomNewick(const int n,const int max);
  const std::vector<int> CreateRandomBinaryNewickVector(const int n,const int max);
  const std::vector<std::string> CreateValidBinaryNewicks();
  const std::vector<std::string> CreateValidNewicks();
  const std::vector<std::string> CreateValidTrinaryNewicks();
  const std::vector<std::string> CreateValidUnaryNewicks();
  const std::string DumbNewickToString(const std::vector<int>& v);
  const std::vector<int> Factorial(const std::vector<int>& v_original);
  const BigInteger FactorialBigInt(const int n);
  int Factorial(const int n);
  int FindPosAfter(const std::vector<int>& v,const int index,const int value);
  int FindPosBefore(const std::vector<int>& v,const int index,const int value);
  const std::vector<int> GetDepth(const std::vector<int>& n);
  const std::vector<int> GetFactorialTerms(const int n);
  int GetLeafMaxArity(const std::vector<int>& n);
  const std::vector<std::vector<int> >
    GetRootBranches(const std::vector<int>& n);
  const std::pair<std::vector<int>,std::vector<int> >
    GetRootBranchesBinary(const std::vector<int>& n);
  const std::vector<std::vector<int> > GetSimplerBinaryNewicks(
    const std::vector<int>& n);
  const std::vector<std::vector<int> > GetSimplerNewicks(
    const std::vector<int>& n);
  const std::vector<std::pair<std::vector<int>,int> >
    GetSimplerNewicksFrequencyPairs(
    const std::vector<int>& n);
  const std::vector<std::pair<std::vector<int>,int> >
    GetSimplerBinaryNewicksFrequencyPairs(
    const std::vector<int>& n);
  void InspectInvalidNewick(std::ostream& os, const std::vector<int>& v);
  bool IsBinaryNewick(std::vector<int> v);
  bool IsTrinaryNewick(std::vector<int> v);
  bool IsUnaryNewick(const std::vector<int>& v);
  bool IsNewick(const std::string& s);
  bool IsNewick(const std::vector<int>& v);
  bool IsSimple(const std::vector<int>& v);
  const std::string NewickToString(const std::vector<int>& v);
  const std::vector<int> ReplaceLeave(const std::vector<int>& newick,const int value);
  const std::vector<int> StringToNewick(const std::string& newick);
  const std::vector<int> Surround(const std::vector<int>& newick);
  void Test();
  char ValueToChar(const int value);

  template <class NewickType>
  double CalculateProbability(
    const NewickType& n,
    const double theta,
    NewickStorage<NewickType>& storage)
{
  //#define TRACE_NEWICK_CALCULATEPROBABILITY
  while(1)
  {
    try
    {
      //Is n already known?
      {
        const double p = storage.Find(n);
        if (p!=0.0)
        {
          return p;
        }
      }

      //Check for simple phylogeny
      if (n.IsSimple())
      {
        const double p = n.CalcProbabilitySimpleNewick(theta);
        storage.Store(n,p);
        return p;
      }
      //Complex
      //Generate other Newicks and their coefficients
      std::vector<double> coefficients;
      std::vector<NewickType> newicks;
      {
        const double d = n.CalcDenominator(theta);
        #ifdef TRACE_NEWICK_CALCULATEPROBABILITY
        TRACE("Denominator for "
          + n.ToStr()
          + " = "
          + boost::lexical_cast<std::string>(d));
        #endif
        typedef std::pair<std::vector<int>,int> NewickFrequencyPair;
        const std::vector<NewickFrequencyPair> newick_freqs
          = Newick::GetSimplerNewicksFrequencyPairs(n.Peek());
        BOOST_FOREACH(const NewickFrequencyPair& p,newick_freqs)
        {
          const int frequency = p.second;
          assert(frequency > 0);
          if (frequency == 1)
          {
            newicks.push_back(p.first);
            coefficients.push_back(theta / d);
          }
          else
          {
            const double f_d = static_cast<double>(frequency);
            newicks.push_back(p.first);
            coefficients.push_back( (f_d*(f_d-1.0)) / d);
          }
          #ifdef TRACE_NEWICK_CALCULATEPROBABILITY
          TRACE(std::string("BinaryNewickVector ")
            + Newick::NewickToString(p.first)
            + " has coefficient "
            + boost::lexical_cast<std::string>(coefficients.back()))
          #endif
        }
      }
      //Ask help about these new Newicks
      {
        const int sz = newicks.size();
        assert(newicks.size() == coefficients.size() );
        double p = 0.0;
        for (int i=0; i!=sz; ++i)
        {
          //Recursive function call
          p+=(coefficients[i] * CalculateProbability(newicks[i],theta,storage));
        }
        storage.Store(n,p);
        return p;
      }
    }
    catch (std::bad_alloc& e)
    {
      storage.CleanUp();
      std::cerr << "std::bad_alloc\n";
    }
    catch (std::exception& e)
    {
      storage.CleanUp();
      std::cerr << "std::exception";
    }
    catch (...)
    {
      storage.CleanUp();
      std::cerr << "Unknown exception\n";
    }
  }
}
//---------------------------------------------------------------------------

  /*
  template <class NewickType>
  double CalculateProbabilityMessy(
    const NewickType& n,
    const double theta,
    NewickStorage<NewickType>& storage)
  {
  //#define TRACE_CALCULATEPROBABILITYMESSY
  while(1)
  {
    try
    {

      //Is n already known?
      {
        const double p = storage.Find(n);
        if (p!=0.0)
        {
          return p;
        }
      }

      //Check for simple phylogeny
      if (n.IsSimple())
      {
        const double p = n.CalcProbabilitySimpleNewick(theta);
        storage.Store(n,p);
        return p;
      }

      //Complex
      //Generate other Newicks and their coefficients
      std::vector<NewickType> newicks;
      std::vector<double> coefficients;
      {
        const double d = n.CalcDenominator(theta);
        #ifdef TRACE_CALCULATEPROBABILITYMESSY
        TRACE("Denominator for "
          + n.ToStr()
          + " = "
          + boost::lexical_cast<std::string>(d));
        #endif
        const std::vector<int>& v = n.Peek();
        const int sz = v.size();
        for (int i=0; i!=sz; ++i)
        {
          const int x = v[i];
          if (x < 0) //x is not a digit
          {
            continue;
          }
          if (x == 1)
          {
            NewickType next_newick = n.TermIsOne(i);
            if (!next_newick.Empty())
            {
              newicks.push_back(next_newick);
              coefficients.push_back(theta / d);
            }
          }
          else
          {
            NewickType next_newick = n.TermIsNotOne(i);
            if (!next_newick.Empty())
            {
              newicks.push_back(next_newick);
              const double x_d = static_cast<double>(x);
              coefficients.push_back( (x_d*(x_d-1.0)) / d);
            }
          }
        }
      }
      //Ask help about these new Newicks
      {
        const int sz = newicks.size();
        assert(newicks.size() == coefficients.size() );
        double p = 0.0;
        for (int i=0; i!=sz; ++i)
        {
          //Recursive function call
          p+=(coefficients[i] * CalculateProbabilityMessy(newicks[i],theta,storage));
        }
        storage.Store(n,p);
        return p;
      }
    }
    catch (std::bad_alloc& e)
    {
      storage.CleanUp();
      std::cerr << "std::bad_alloc\n";
    }
    catch (std::exception& e)
    {
      storage.CleanUp();
      std::cerr << "std::exception";
    }
    catch (...)
    {
      storage.CleanUp();
      std::cerr << "Unknown exception\n";
    }

  }
}
*/
//#endif
//---------------------------------------------------------------------------

};
//---------------------------------------------------------------------------
#endif // NEWICK_H

