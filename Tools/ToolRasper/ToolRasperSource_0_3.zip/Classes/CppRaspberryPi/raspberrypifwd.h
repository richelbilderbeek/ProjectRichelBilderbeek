#ifndef RASPBERRYPIFWD_H
#define RASPBERRYPIFWD_H

namespace rpi {
  namespace gpio {
    struct Pin;
  } //~namespace gpio
} //namespace rpi

#endif // RASPBERRYPIFWD_H
