//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
//#include <richel001.h>
#include <math.h>
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

enum STATE {EMPTY, SUS, RES, KILL};    // Some global definitions
STATE area[400][400];
int NEmpty=0;
int NSus=0;
int NRes=0;
int NKill=0;
double deathrate=0.0;
double birthrate=0.0;
double cost_of_res=0.0;
double extra_death_kil=0.0;
double mut=0.0;
int duration=0;
int maxx=0;
int maxy=0;
double initsus=0.0;
double initres=0.0;
double initkill=0.0;
int diffusion=0;

//////////////////////
/// Mobius Function///
//////////////////////
template <class T>
void Mobius(T &number,T min, T max)
  {
  if (number>max) {number-=(max+min);}
  if (number<min) {number+=(max-min);}
  }//End of: void Mobius

////////////////////////////////////////////////////////////
// Choose from a 4 neighborhood at max distance diffusion///
////////////////////////////////////////////////////////////

void FindNeighbour(int x1, int y1, int &x2, int& y2, int diffusion)
  {
   x2=x1+(random(2*diffusion+1)-diffusion);
   y2=y1+(random(2*diffusion+1)-diffusion);
   while (x2==x1 && y2==y1)
     {
      x2=x1+(random(2*diffusion+1)-diffusion);
      y2=y1+(random(2*diffusion+1)-diffusion);
     }
  /*switch(random(4))
    {
    case 0 : y2=y1-diffusion; x2=x1; break;
    case 1 : x2=x1-diffusion; y2=y1; break;
    case 2 : y2=y1+diffusion; x2=x1; break;
    case 3 : x2=x1-diffusion; y2=y1; break;
    }//End of: switch (random(4))*/
  }

/////////////////////////////////////
/// Map states to colors ////////////
/////////////////////////////////////

TColor StateToColor(STATE number)
  {
  TColor solution=clWhite;
  if (number==EMPTY) solution=clBlack;
  if (number==SUS) solution=clYellow;
  if (number==RES) solution=clLime;
  if (number==KILL) solution=clRed;
  return (solution);
  }

////////////////////////////////////////////////////////////
// EMPTY THE CHART
////////////////////////////////////////////////////////////
void EmptyChart(TChart * Chart1)
  {
  Chart1->Series[0]->Clear();
  Chart1->Series[1]->Clear();
  Chart1->Series[2]->Clear();
  Chart1->Series[3]->Clear();
  }

////////////////////////////////////////////////////////////
// INITIALIZE THE GRID
////////////////////////////////////////////////////////////
void Init_grid(void)
  {
  for (int x=0; x<maxx; x++)
    {
    for (int y=0; y<maxy; y++)
      {
      //ShowMessage(initsus);
      double ran1=rnd::uniform();
      if (ran1 < initsus) {area[x][y]=SUS;  continue; }
      if (ran1 > initsus &&  ran1 < initsus+initres) {area[x][y]=RES; continue;}
      if (ran1 > initsus+initres  && ran1 < initsus+initres+initkill) {area[x][y]=KILL; continue;}
      area[x][y]=EMPTY;
      }// next y
    }// next x
  }//End of: Init_grid


////////////////////////////////////////////////////////////
// UPDATE THE GRID
////////////////////////////////////////////////////////////
void GridUpdate(void)
  {
  int x1,y1,x2,y2;
  for (y1=0; y1<maxy; y1++)
    {
    for (x1=0; x1<maxx; x1++)
      {
      FindNeighbour(x1,y1,x2,y2,diffusion);
      Mobius(x2,0,maxx-1);
      Mobius(y2,0,maxy-1);
      //Update rule
      STATE Here=area[x1][y1];
      STATE Neighbour=area[x2][y2];
      double ran1=rnd::uniform();
      double ran2=rnd::uniform();
      switch (Here)
        {
        case EMPTY : if ((ran1 < birthrate) && (Neighbour==SUS))
                       {
                        area[x1][y1]=SUS; //Birth: If res/sus are neighbor
                       }

                     else if ((ran2 < birthrate-cost_of_res) && (Neighbour==RES))
                       {
                        area[x1][y1]=RES;
                       }
                     break;

        case SUS   : if (ran2 < deathrate  || Neighbour==KILL)
                       {
                        area[x1][y1]=EMPTY; //Mortality of Sus
                       }
                     break;

        case RES   : if (ran2 < deathrate)
                       {
                       area[x1][y1]=EMPTY; // Mortality of Res
                       }
                     else if (ran1 < mut) //Mutation: Res becomes Kil
                       {
                       area[x1][y1]=KILL;
                       }
                     break;

        case KILL  : if (ran1 < deathrate + extra_death_kil)
                       {
                       area[x1][y1]=EMPTY; //Mortality of Kil
                       }
                     break;
        }//End of: switch(Here)
      }//Next x
    }//Next y
  }//End of: void Update(void)

////////////////////////////////////////////////////////////
// EXAMINE THE GRID
////////////////////////////////////////////////////////////
void CountValues(void)
  {
  //Reset values
  NEmpty=0; NSus=0; NRes=0; NKill=0;
  //Count total grid
  for (int y=0; y<maxy; y++)
    {
    for (int x=0; x<maxx; x++)
      {
      if (area[x][y]==EMPTY) NEmpty++;
      if (area[x][y]==SUS) NSus++;
      if (area[x][y]==RES) NRes++;
      if (area[x][y]==KILL) NKill++;
      }//Next x
    }//Next y
  }//End of: void CountValues(void)

////////////////////////////////////////////////////////////
// DISPLAY THE VALUES IN THE CHART
////////////////////////////////////////////////////////////
void DisplayValues(TChart * Chart1)
  {
  /// Graphical Output timeseries
  Chart1->Series[0]->Add(NEmpty);
  Chart1->Series[1]->Add(NSus);
  Chart1->Series[2]->Add(NRes);
  Chart1->Series[3]->Add(NKill);
  Chart1->Refresh();
  }

///////////////////////////////////////////////////////
//   SHOW AREA
///////////////////////////////////////////////////////
void ShowArea(TPaintBox * PaintBox1)
  {
  int x,y;
  for (y=0; y<maxy; y++)
    {
    for (x=0; x<maxx; x++)
      {
      PaintBox1->Canvas->Pixels[x][y]=StateToColor(area[x][y]);
      }//Next x
    }//Next y
  }//End of: void ShowArea(..)

//---------------------------------------------------------------------------
// CONSTRUCTOR OF FORM
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------

///////////////////////////////////////////////////////
//   MAIN FUNCTION ////////////////////////////////////
///////////////////////////////////////////////////////
void __fastcall TForm1::Button1Click(TObject *Sender)
{
// Read in Parameters
birthrate = ValueListEditor1->Cells[1][1].ToDouble();
deathrate =ValueListEditor1->Cells[1][2].ToDouble();
cost_of_res =ValueListEditor1->Cells[1][3].ToDouble();
extra_death_kil =ValueListEditor1->Cells[1][4].ToDouble();
mut =ValueListEditor1->Cells[1][5].ToDouble();
initsus =ValueListEditor1->Cells[1][6].ToDouble();
initres =ValueListEditor1->Cells[1][7].ToDouble();
initkill =ValueListEditor1->Cells[1][8].ToDouble();
maxx=ValueListEditor1->Cells[1][9].ToInt();
maxy=ValueListEditor1->Cells[1][10].ToInt();
duration=ValueListEditor1->Cells[1][11].ToInt();
diffusion=ValueListEditor1->Cells[1][12].ToInt();

EmptyChart(Chart1);
Init_grid(); //Initialize grid
CountValues();
DisplayValues(Chart1);
ShowArea(PaintBox1);

for (int time=0; time<duration; time++)
  {
  GridUpdate();
  CountValues();
  DisplayValues(Chart1);
  ShowArea(PaintBox1);
  }//Next time
}
//--------------------------------------------------------------------------


