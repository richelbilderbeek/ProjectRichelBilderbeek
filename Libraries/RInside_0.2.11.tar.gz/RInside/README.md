# Easier embedding of R inside C++

[![Build Status](https://travis-ci.org/eddelbuettel/rinside.png)](https://travis-ci.org/eddelbuettel/rinside)

The RInside package provides a few classes for seamless embedding R inside of
C++ applications.

## License

GPL (>= 2)
