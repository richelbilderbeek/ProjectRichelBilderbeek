int truncate (const char *filename, long size)
{
    return 0;
}
