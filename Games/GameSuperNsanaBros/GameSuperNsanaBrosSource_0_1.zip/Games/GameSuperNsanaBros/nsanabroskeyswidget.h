#ifndef NSANABROSKEYSWIDGET_H
#define NSANABROSKEYSWIDGET_H
//---------------------------------------------------------------------------
#include <boost/noncopyable.hpp>
//---------------------------------------------------------------------------
struct NsanaBrosKeysWidget : public boost::noncopyable
{
  NsanaBrosKeysWidget();
};
//---------------------------------------------------------------------------
#endif // NSANABROSKEYSWIDGET_H
