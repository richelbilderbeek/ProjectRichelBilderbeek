//---------------------------------------------------------------------------
#include "nsanabrosstlheader.h"
//---------------------------------------------------------------------------
NsanaBrosGameDialog::NsanaBrosGameDialog(
  const NsanaBrosOptions * const options)
  : m_options(options)

{

  //d->m_signal_close.connect(
  //  boost::bind(
  //  &WtTestAsciiArterDialog::ShowMain,
  //  this));

}
//---------------------------------------------------------------------------

