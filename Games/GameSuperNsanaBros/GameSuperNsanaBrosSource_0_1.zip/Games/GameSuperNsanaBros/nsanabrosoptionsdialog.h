#ifndef NSANABROSOPTIONSDIALOG_H
#define NSANABROSOPTIONSDIALOG_H
//---------------------------------------------------------------------------
#include <boost/checked_delete.hpp>
#include <boost/noncopyable.hpp>
#include <boost/scoped_ptr.hpp>
//---------------------------------------------------------------------------
struct NsanaBrosOptions;
//---------------------------------------------------------------------------
struct NsanaBrosOptionsDialog : public boost::noncopyable
{
  NsanaBrosOptionsDialog();

  const NsanaBrosOptions * GetOptions() const;

  private:
  ~NsanaBrosOptionsDialog() {}
  friend void boost::checked_delete<>(NsanaBrosOptionsDialog *);

  boost::scoped_ptr<NsanaBrosOptions> m_options;
};
//---------------------------------------------------------------------------
#endif // NSANABROSOPTIONSDIALOG_H
