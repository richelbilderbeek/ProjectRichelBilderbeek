//---------------------------------------------------------------------------
//#include <Wt/WMouseEvent>
#include <Wt/WPaintedWidget>
#include <Wt/WPaintDevice>
//---------------------------------------------------------------------------
#include "nsanabroswtheader.h"
//---------------------------------------------------------------------------
WtNsanaBrosGameAreaWidget::WtNsanaBrosGameAreaWidget()
{

}
//---------------------------------------------------------------------------
void WtNsanaBrosGameAreaWidget::paintEvent(Wt::WPaintDevice *paintDevice)
{

}
//---------------------------------------------------------------------------




