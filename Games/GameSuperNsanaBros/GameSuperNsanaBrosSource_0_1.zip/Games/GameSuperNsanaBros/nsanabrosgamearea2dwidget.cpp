//---------------------------------------------------------------------------
#include "nsanabrosstlheader.h"
//---------------------------------------------------------------------------
NsanaBrosGameArea2dWidget::NsanaBrosGameArea2dWidget()
{

}
//---------------------------------------------------------------------------
/*
const NsanaBrosGameArea2d * NsanaBrosGameArea2dWidget::GetArea() const
{
  return m_area.get();
}
//---------------------------------------------------------------------------
void NsanaBrosGameArea2dWidget::KeyPress(const int key)
{
  m_keys->KeyPress(key);
  OnTimer();
}
//---------------------------------------------------------------------------
void NsanaBrosGameArea2dWidget::KeyRelease(const int key)
{
  m_keys->KeyRelease(key);
  OnTimer();
}
//---------------------------------------------------------------------------
void NsanaBrosGameArea2dWidget::OnTimer()
{
  m_area->OnTimer();
}
//---------------------------------------------------------------------------
const std::vector<const NsanaBrosSprite*> NsanaBrosGameArea2dWidget::GetSprites() const
{
  std::vector<const NsanaBrosSprite *> v = m_area->GetSprites();
  v.push_back(m_area->GetPlayer()->GetSprite());
  return v;
}
//---------------------------------------------------------------------------
*/


