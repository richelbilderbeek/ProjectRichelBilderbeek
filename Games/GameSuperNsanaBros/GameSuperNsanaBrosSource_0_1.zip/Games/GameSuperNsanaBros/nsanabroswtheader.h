#ifndef NSANABROSWTHEADER_H
#define NSANABROSWTHEADER_H

///This header file #includes all Wt classes
#include "nsanabrosstlheader.h"

#include "wtaboutdialog.h"
#include "wtnsanabrosgameareawidget.h"
#include "wtnsanabrosgamedialog.h"
#include "wtnsanabroskeyswidget.h"
#include "wtnsanabrosmenudialog.h"
#include "wtnsanabrosoptionsdialog.h"

#endif // NSANABROSWTHEADER_H
