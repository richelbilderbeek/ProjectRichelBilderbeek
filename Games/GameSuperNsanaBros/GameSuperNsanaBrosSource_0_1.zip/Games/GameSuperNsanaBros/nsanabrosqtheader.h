#ifndef NSANABROSQTHEADER_H
#define NSANABROSQTHEADER_H

///This header file #includes all Qt classes
#include "nsanabrosstlheader.h"

#include "qtaboutdialog.h"
#include "qtnsanabrosgamearea2dwidget.h"
#include "qtnsanabrosgamedialog.h"
#include "qtnsanabroskeyswidget.h"
#include "qtnsanabrosmenudialog.h"
#include "qtnsanabrosoptionsdialog.h"

#endif // NSANABROSQTHEADER_H
