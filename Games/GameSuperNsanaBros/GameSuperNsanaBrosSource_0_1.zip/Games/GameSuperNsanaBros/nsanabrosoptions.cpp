#include "nsanabrosoptions.h"

NsanaBrosOptions::NsanaBrosOptions()
  : m_show_one_dimensional(true),
    m_show_two_dimensional(true),
    m_show_keys(true)
{

}
