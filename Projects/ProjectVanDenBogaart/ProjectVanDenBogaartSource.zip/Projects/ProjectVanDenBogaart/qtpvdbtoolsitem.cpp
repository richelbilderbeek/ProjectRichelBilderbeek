#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "qtpvdbtoolsitem.h"

#include <QCursor>
#include <QPainter>
#include <QGraphicsSceneMouseEvent>
#include "qtpvdbnodeitem.h"
#include "trace.h"

QtPvdbToolsItem::QtPvdbToolsItem()
  : m_signal_clicked(),
    m_item(nullptr)
{
  this->setPixmap(QPixmap(":/images/PicArrow14x14.png"));

  assert(!this->pixmap().isNull());

  this->setFlags(
      QGraphicsItem::ItemIsFocusable
    | QGraphicsItem::ItemIsSelectable);

  //Allow mouse tracking
  this->setAcceptHoverEvents(true);

  this->setVisible(false);

  this->setZValue(3.0);
}

const QtPvdbNodeItem * QtPvdbToolsItem::GetBuddyItem() const
{
  assert(m_item);
  return m_item;
}


void QtPvdbToolsItem::hoverMoveEvent(QGraphicsSceneHoverEvent *)
{
  this->setCursor(QCursor(Qt::PointingHandCursor));
}

void QtPvdbToolsItem::mousePressEvent(QGraphicsSceneMouseEvent * event)
{
  QGraphicsPixmapItem::mousePressEvent(event);
  m_signal_clicked();
}

void QtPvdbToolsItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
  assert(m_item);
  this->setPos(
    m_item->pos().x(),
    m_item->pos().y() - 32.0);

  QGraphicsPixmapItem::paint(painter,option,widget);

  if (this->isSelected() || this->hasFocus())
  {
    QPen pen;
    pen.setColor(QColor(255,0,0));
    painter->setPen(pen);
    //No idea why these relative coordinats are best
    //I'd expect no adjustment to look best...
    painter->drawRect(this->boundingRect().adjusted(0.0,0.0,-2.0,-2.0));
  }
}

void QtPvdbToolsItem::SetBuddyItem(const QtPvdbNodeItem * const item)
{
  if (item != m_item)
  {
    m_item = item;
    if (m_item)
    {
      this->setVisible(true);
      this->update();
    }
    else
    {
      this->setVisible(false);
    }
  }
}
