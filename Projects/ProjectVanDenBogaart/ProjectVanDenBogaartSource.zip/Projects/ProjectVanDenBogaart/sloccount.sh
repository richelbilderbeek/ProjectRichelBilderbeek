sloccount --overhead 1.0 --personcost 22994.56 ../ProjectVanDenBogaart > ProjectVanDenBogaartSloccount.txt
