from ldtp import *
from ldtputils import *
selectmenuitem ('*-gedit', 'mnuFile;mnuNew')
