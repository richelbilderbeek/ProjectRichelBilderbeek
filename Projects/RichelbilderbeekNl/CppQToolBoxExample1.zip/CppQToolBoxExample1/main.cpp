#include <QtGui/QApplication>
#include "cppqtoolboxexample1dialog.h"

int main(int argc, char *argv[])
{
  QApplication a(argc, argv);
  CppQToolBoxExample1Dialog w;
  w.show();
  
  return a.exec();
}
