#ifndef CPPQTOOLBOXEXAMPLE1DIALOG_H
#define CPPQTOOLBOXEXAMPLE1DIALOG_H

#include <QDialog>

namespace Ui {
  class CppQToolBoxExample1Dialog;
}

class CppQToolBoxExample1Dialog : public QDialog
{
  Q_OBJECT
  
public:
  explicit CppQToolBoxExample1Dialog(QWidget *parent = 0);
  ~CppQToolBoxExample1Dialog();
  
private slots:
  void on_pushButton_1_clicked();

  void on_pushButton_2_clicked();

  void on_pushButton_3_clicked();

private:
  Ui::CppQToolBoxExample1Dialog *ui;
};

#endif // CPPQTOOLBOXEXAMPLE1DIALOG_H
