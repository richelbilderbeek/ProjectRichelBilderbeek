#include "cppqtoolboxexample1dialog.h"
#include "ui_cppqtoolboxexample1dialog.h"

CppQToolBoxExample1Dialog::CppQToolBoxExample1Dialog(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::CppQToolBoxExample1Dialog)
{
  ui->setupUi(this);
}

CppQToolBoxExample1Dialog::~CppQToolBoxExample1Dialog()
{
  delete ui;
}

void CppQToolBoxExample1Dialog::on_pushButton_1_clicked()
{
  ui->label->setText("1");
}

void CppQToolBoxExample1Dialog::on_pushButton_2_clicked()
{
  ui->label->setText("2");
}

void CppQToolBoxExample1Dialog::on_pushButton_3_clicked()
{
  ui->label->setText("3");
}
