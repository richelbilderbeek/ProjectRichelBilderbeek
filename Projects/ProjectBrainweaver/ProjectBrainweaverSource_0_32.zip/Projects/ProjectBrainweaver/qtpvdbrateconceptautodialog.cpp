#include "qtpvdbrateconceptautodialog.h"

#include <cassert>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <QKeyEvent>
#include "pvdbconceptmap.h"
#include "pvdbconcept.h"
#include "pvdbnode.h"
#include "pvdbexample.h"
#include "pvdbexamples.h"
#include "ui_qtpvdbrateconceptautodialog.h"

QtPvdbRateConceptAutoDialog::QtPvdbRateConceptAutoDialog(
  const boost::shared_ptr<pvdb::ConceptMap> sub_concept_map,
  QWidget *parent)
  : QtHideAndShowDialog(parent),
    ui(new Ui::QtPvdbRateConceptAutoDialog)
{
  ui->setupUi(this);

  ui->table->setColumnWidth(0,24);
  ui->table->setColumnWidth(1,24);
  ui->table->setColumnWidth(2,24);
  ui->table->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
  assert(sub_concept_map);
  assert(!sub_concept_map->GetNodes().empty());
  const boost::shared_ptr<const pvdb::Concept> focal_concept = sub_concept_map->GetNodes().at(0)->GetConcept();
  assert(focal_concept);
  ui->label_concept_name->setText(
    (std::string("Concept: ") + focal_concept->GetName()).c_str() );
  //Collect all examples of the focal node of this sub concept map
  //Put X,C,S checkboxes in front
  for (const boost::shared_ptr<const pvdb::Example> example: focal_concept->GetExamples()->Get())
  {
    assert(example);
    const int row = ui->table->rowCount();
    ui->table->setRowCount(row + 1);
    const int n_cols = ui->table->columnCount();
    assert(n_cols == 4);
    for (int col=0; col!=n_cols; ++col)
    {
      QTableWidgetItem * const i = new QTableWidgetItem;
      if (col != 3)
      {
        //Checkbox
        i->setFlags(
            Qt::ItemIsSelectable
          | Qt::ItemIsUserCheckable
          | Qt::ItemIsEnabled
        );
        i->setCheckState(Qt::Checked);
      }
      else
      {
        //Text

        i->setFlags(
            Qt::ItemIsSelectable
          | Qt::ItemIsEditable
          | Qt::ItemIsEnabled);
        const std::string s = example->GetText();
        i->setText(s.c_str());
      }
      ui->table->setItem(row, col, i);
    }
  }

  //Collect all relations of the focal node of this sub concept map
  //Put X checkbox in the relation's name
  {
    //Of every relation, collect all examples
    //Put X,C,S checkboxes in front
  }

}

QtPvdbRateConceptAutoDialog::~QtPvdbRateConceptAutoDialog()
{
  delete ui;
}

void QtPvdbRateConceptAutoDialog::keyPressEvent(QKeyEvent * event)
{
  if (event->key() == Qt::Key_Escape) { close(); return; }
}

//void QtPvdbRateConceptAutoDialog::resizeEvent(QResizeEvent *)
//{
//  ui->table->setColumnWidth(3,ui->table->width() - (3 * 24) - (3 * 5));
//}
