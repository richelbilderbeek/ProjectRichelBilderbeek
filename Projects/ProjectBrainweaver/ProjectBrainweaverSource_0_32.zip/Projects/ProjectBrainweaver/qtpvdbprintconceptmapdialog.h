#ifndef QTPVDBPRINTCONCEPTMAPDIALOG_H
#define QTPVDBPRINTCONCEPTMAPDIALOG_H

#include <boost/shared_ptr.hpp>

#include "pvdbfwd.h"
#include "qthideandshowdialog.h"

namespace Ui {
  class QtPvdbPrintConceptMapDialog;
}

///View the current work, optimized for humans
///This dialog will not be visible for humans at all in release
///QtPvdbPrintConceptMapDialog is optimized for printers
class QtPvdbPrintConceptMapDialog : public QtHideAndShowDialog
{
  Q_OBJECT
  
public:
  explicit QtPvdbPrintConceptMapDialog(
    const boost::shared_ptr<const pvdb::File>& file,
    QWidget *parent = 0);
  ~QtPvdbPrintConceptMapDialog();
  void Print();

protected:
  void keyPressEvent(QKeyEvent * event);
  void showEvent(QShowEvent *);

private slots:
  void on_button_print_clicked();

private:
  Ui::QtPvdbPrintConceptMapDialog *ui;

  const boost::shared_ptr<const pvdb::File> m_file;

  const std::vector<QWidget *> CollectWidgets() const;

};

#endif // QTPVDBPRINTCONCEPTMAPDIALOG_H
