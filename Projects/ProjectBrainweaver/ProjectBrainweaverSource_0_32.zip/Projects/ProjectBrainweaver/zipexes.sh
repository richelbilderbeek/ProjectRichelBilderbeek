#!/bin/sh
zip ProjectBrainweaverExe.zip *.exe
