#!/bin/sh

echo "Removing user information"
rm *.user

echo "Removing possible temp file"
rm copy.txt
rm tmp.txt


echo "Creating of all main folders"

mkdir temp_zip
mkdir temp_zip/Classes
mkdir temp_zip/Projects
mkdir temp_zip/Tools

echo "Creating of all subfolders"

mkdir temp_zip/Classes/CppAbout
mkdir temp_zip/Classes/CppFuzzy_equal_to
mkdir temp_zip/Classes/CppLazy_init
mkdir temp_zip/Classes/CppQtAboutDialog
mkdir temp_zip/Classes/CppQtArrowItem
mkdir temp_zip/Classes/CppQtHideAndShowDialog
mkdir temp_zip/Classes/CppQtKeyboardFriendlyGraphicsView
mkdir temp_zip/Classes/CppQtLabeledQuadBezierArrowItem
mkdir temp_zip/Classes/CppQtPathArrowItem
mkdir temp_zip/Classes/CppQtQuadBezierArrowItem
mkdir temp_zip/Classes/CppQtRoundedEditRectItem
mkdir temp_zip/Classes/CppQtRoundedRectItem
mkdir temp_zip/Classes/CppQtRoundedTextRectItem
mkdir temp_zip/Classes/CppQtScopedDisable
mkdir temp_zip/Classes/CppTrace
mkdir temp_zip/Projects/ProjectBrainweaver
mkdir temp_zip/Tools/ToolStyleSheetSetter
mkdir temp_zip/Tools/ToolTestQtArrowItems
mkdir temp_zip/Tools/ToolTestQtRoundedEditRectItem
mkdir temp_zip/Tools/ToolTestQtRoundedTextRectItem

echo "Copying files"

cp ../../Classes/CppAbout/Licence.txt temp_zip/Classes/CppAbout/Licence.txt
cp ../../Classes/CppAbout/about.cpp temp_zip/Classes/CppAbout/about.cpp
cp ../../Classes/CppAbout/about.h temp_zip/Classes/CppAbout/about.h
cp ../../Classes/CppFuzzy_equal_to/Licence.txt temp_zip/Classes/CppFuzzy_equal_to/Licence.txt
cp ../../Classes/CppFuzzy_equal_to/fuzzy_equal_to.h temp_zip/Classes/CppFuzzy_equal_to/fuzzy_equal_to.h
cp ../../Classes/CppLazy_init/Licence.txt temp_zip/Classes/CppLazy_init/Licence.txt
cp ../../Classes/CppQtAboutDialog/Licence.txt temp_zip/Classes/CppQtAboutDialog/Licence.txt
cp ../../Classes/CppQtAboutDialog/qtaboutdialog.cpp temp_zip/Classes/CppQtAboutDialog/qtaboutdialog.cpp
cp ../../Classes/CppQtAboutDialog/qtaboutdialog.h temp_zip/Classes/CppQtAboutDialog/qtaboutdialog.h
cp ../../Classes/CppQtAboutDialog/qtaboutdialog.ui temp_zip/Classes/CppQtAboutDialog/qtaboutdialog.ui
cp ../../Classes/CppQtArrowItem/Licence.txt temp_zip/Classes/CppQtArrowItem/Licence.txt
cp ../../Classes/CppQtArrowItem/qtarrowitem.cpp temp_zip/Classes/CppQtArrowItem/qtarrowitem.cpp
cp ../../Classes/CppQtArrowItem/qtarrowitem.h temp_zip/Classes/CppQtArrowItem/qtarrowitem.h
cp ../../Classes/CppQtHideAndShowDialog/Licence.txt temp_zip/Classes/CppQtHideAndShowDialog/Licence.txt
cp ../../Classes/CppQtHideAndShowDialog/qthideandshowdialog.cpp temp_zip/Classes/CppQtHideAndShowDialog/qthideandshowdialog.cpp
cp ../../Classes/CppQtHideAndShowDialog/qthideandshowdialog.h temp_zip/Classes/CppQtHideAndShowDialog/qthideandshowdialog.h
cp ../../Classes/CppQtKeyboardFriendlyGraphicsView/Licence.txt temp_zip/Classes/CppQtKeyboardFriendlyGraphicsView/Licence.txt
cp ../../Classes/CppQtKeyboardFriendlyGraphicsView/qtkeyboardfriendlygraphicsview.cpp temp_zip/Classes/CppQtKeyboardFriendlyGraphicsView/qtkeyboardfriendlygraphicsview.cpp
cp ../../Classes/CppQtKeyboardFriendlyGraphicsView/qtkeyboardfriendlygraphicsview.h temp_zip/Classes/CppQtKeyboardFriendlyGraphicsView/qtkeyboardfriendlygraphicsview.h
cp ../../Classes/CppQtLabeledQuadBezierArrowItem/Licence.txt temp_zip/Classes/CppQtLabeledQuadBezierArrowItem/Licence.txt
cp ../../Classes/CppQtLabeledQuadBezierArrowItem/qtlabeledquadbezierarrowitem.cpp temp_zip/Classes/CppQtLabeledQuadBezierArrowItem/qtlabeledquadbezierarrowitem.cpp
cp ../../Classes/CppQtLabeledQuadBezierArrowItem/qtlabeledquadbezierarrowitem.h temp_zip/Classes/CppQtLabeledQuadBezierArrowItem/qtlabeledquadbezierarrowitem.h
cp ../../Classes/CppQtPathArrowItem/Licence.txt temp_zip/Classes/CppQtPathArrowItem/Licence.txt
cp ../../Classes/CppQtPathArrowItem/qtpatharrowitem.cpp temp_zip/Classes/CppQtPathArrowItem/qtpatharrowitem.cpp
cp ../../Classes/CppQtPathArrowItem/qtpatharrowitem.h temp_zip/Classes/CppQtPathArrowItem/qtpatharrowitem.h
cp ../../Classes/CppQtQuadBezierArrowItem/Licence.txt temp_zip/Classes/CppQtQuadBezierArrowItem/Licence.txt
cp ../../Classes/CppQtQuadBezierArrowItem/qtquadbezierarrowitem.cpp temp_zip/Classes/CppQtQuadBezierArrowItem/qtquadbezierarrowitem.cpp
cp ../../Classes/CppQtQuadBezierArrowItem/qtquadbezierarrowitem.h temp_zip/Classes/CppQtQuadBezierArrowItem/qtquadbezierarrowitem.h
cp ../../Classes/CppQtRoundedEditRectItem/Licence.txt temp_zip/Classes/CppQtRoundedEditRectItem/Licence.txt
cp ../../Classes/CppQtRoundedEditRectItem/qtroundededitrectitem.cpp temp_zip/Classes/CppQtRoundedEditRectItem/qtroundededitrectitem.cpp
cp ../../Classes/CppQtRoundedEditRectItem/qtroundededitrectitem.h temp_zip/Classes/CppQtRoundedEditRectItem/qtroundededitrectitem.h
cp ../../Classes/CppQtRoundedRectItem/Licence.txt temp_zip/Classes/CppQtRoundedRectItem/Licence.txt
cp ../../Classes/CppQtRoundedRectItem/qtroundedrectitem.cpp temp_zip/Classes/CppQtRoundedRectItem/qtroundedrectitem.cpp
cp ../../Classes/CppQtRoundedRectItem/qtroundedrectitem.h temp_zip/Classes/CppQtRoundedRectItem/qtroundedrectitem.h
cp ../../Classes/CppQtRoundedTextRectItem/Licence.txt temp_zip/Classes/CppQtRoundedTextRectItem/Licence.txt
cp ../../Classes/CppQtRoundedTextRectItem/qtroundedtextrectitem.cpp temp_zip/Classes/CppQtRoundedTextRectItem/qtroundedtextrectitem.cpp
cp ../../Classes/CppQtRoundedTextRectItem/qtroundedtextrectitem.h temp_zip/Classes/CppQtRoundedTextRectItem/qtroundedtextrectitem.h
cp ../../Classes/CppQtScopedDisable/Licence.txt temp_zip/Classes/CppQtScopedDisable/Licence.txt
cp ../../Classes/CppQtScopedDisable/qtscopeddisable.h temp_zip/Classes/CppQtScopedDisable/qtscopeddisable.h
cp ../../Classes/CppTrace/Licence.txt temp_zip/Classes/CppTrace/Licence.txt
cp ../../Classes/CppTrace/trace.h temp_zip/Classes/CppTrace/trace.h
cp ../../Projects/ProjectBrainweaver/1.cmp temp_zip/Projects/ProjectBrainweaver/1.cmp
cp ../../Projects/ProjectBrainweaver/2.cmp temp_zip/Projects/ProjectBrainweaver/2.cmp
cp ../../Projects/ProjectBrainweaver/3.cmp temp_zip/Projects/ProjectBrainweaver/3.cmp
cp ../../Projects/ProjectBrainweaver/4.cmp temp_zip/Projects/ProjectBrainweaver/4.cmp
cp ../../Projects/ProjectBrainweaver/5.cmp temp_zip/Projects/ProjectBrainweaver/5.cmp
cp ../../Projects/ProjectBrainweaver/Brainweaver.qrc temp_zip/Projects/ProjectBrainweaver/Brainweaver.qrc
cp ../../Projects/ProjectBrainweaver/BrainweaverAssessor.pro temp_zip/Projects/ProjectBrainweaver/BrainweaverAssessor.pro
cp ../../Projects/ProjectBrainweaver/BrainweaverDeveloper.pro temp_zip/Projects/ProjectBrainweaver/BrainweaverDeveloper.pro
cp ../../Projects/ProjectBrainweaver/BrainweaverStudent.pro temp_zip/Projects/ProjectBrainweaver/BrainweaverStudent.pro
cp ../../Projects/ProjectBrainweaver/Cluster.png temp_zip/Projects/ProjectBrainweaver/Cluster.png
cp ../../Projects/ProjectBrainweaver/ClusterSkip.png temp_zip/Projects/ProjectBrainweaver/ClusterSkip.png
cp ../../Projects/ProjectBrainweaver/ConceptMapEdit.png temp_zip/Projects/ProjectBrainweaver/ConceptMapEdit.png
cp ../../Projects/ProjectBrainweaver/PicArrow.png temp_zip/Projects/ProjectBrainweaver/PicArrow.png
cp ../../Projects/ProjectBrainweaver/PicArrow14x14.png temp_zip/Projects/ProjectBrainweaver/PicArrow14x14.png
cp ../../Projects/ProjectBrainweaver/PicArrow28x28.png temp_zip/Projects/ProjectBrainweaver/PicArrow28x28.png
cp ../../Projects/ProjectBrainweaver/PicBlue.png temp_zip/Projects/ProjectBrainweaver/PicBlue.png
cp ../../Projects/ProjectBrainweaver/PicBlue14x14.png temp_zip/Projects/ProjectBrainweaver/PicBlue14x14.png
cp ../../Projects/ProjectBrainweaver/PicCyan.png temp_zip/Projects/ProjectBrainweaver/PicCyan.png
cp ../../Projects/ProjectBrainweaver/PicCyan14x14.png temp_zip/Projects/ProjectBrainweaver/PicCyan14x14.png
cp ../../Projects/ProjectBrainweaver/PicGreen.png temp_zip/Projects/ProjectBrainweaver/PicGreen.png
cp ../../Projects/ProjectBrainweaver/PicGreen14x14.png temp_zip/Projects/ProjectBrainweaver/PicGreen14x14.png
cp ../../Projects/ProjectBrainweaver/PicOrange.png temp_zip/Projects/ProjectBrainweaver/PicOrange.png
cp ../../Projects/ProjectBrainweaver/PicOrange14x14.png temp_zip/Projects/ProjectBrainweaver/PicOrange14x14.png
cp ../../Projects/ProjectBrainweaver/PicPurple.png temp_zip/Projects/ProjectBrainweaver/PicPurple.png
cp ../../Projects/ProjectBrainweaver/PicPurple14x14.png temp_zip/Projects/ProjectBrainweaver/PicPurple14x14.png
cp ../../Projects/ProjectBrainweaver/PicRed.png temp_zip/Projects/ProjectBrainweaver/PicRed.png
cp ../../Projects/ProjectBrainweaver/PicRed14x14.png temp_zip/Projects/ProjectBrainweaver/PicRed14x14.png
cp ../../Projects/ProjectBrainweaver/PicWhite.png temp_zip/Projects/ProjectBrainweaver/PicWhite.png
cp ../../Projects/ProjectBrainweaver/PicWhite14x14.png temp_zip/Projects/ProjectBrainweaver/PicWhite14x14.png
cp ../../Projects/ProjectBrainweaver/PicYellow.png temp_zip/Projects/ProjectBrainweaver/PicYellow.png
cp ../../Projects/ProjectBrainweaver/PicYellow14x14.png temp_zip/Projects/ProjectBrainweaver/PicYellow14x14.png
cp ../../Projects/ProjectBrainweaver/ProjectVanDenBogaartArchitecture.lyx~ temp_zip/Projects/ProjectBrainweaver/ProjectVanDenBogaartArchitecture.lyx~
cp ../../Projects/ProjectBrainweaver/R.png temp_zip/Projects/ProjectBrainweaver/R.png
cp ../../Projects/ProjectBrainweaver/crosscompiletowindows.sh temp_zip/Projects/ProjectBrainweaver/crosscompiletowindows.sh
cp ../../Projects/ProjectBrainweaver/doxygen_config.txt temp_zip/Projects/ProjectBrainweaver/doxygen_config.txt
cp ../../Projects/ProjectBrainweaver/pvdbcluster.cpp temp_zip/Projects/ProjectBrainweaver/pvdbcluster.cpp
cp ../../Projects/ProjectBrainweaver/pvdbcluster.h temp_zip/Projects/ProjectBrainweaver/pvdbcluster.h
cp ../../Projects/ProjectBrainweaver/pvdbclusterfactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbclusterfactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbclusterfactory.h temp_zip/Projects/ProjectBrainweaver/pvdbclusterfactory.h
cp ../../Projects/ProjectBrainweaver/pvdbcompetency.cpp temp_zip/Projects/ProjectBrainweaver/pvdbcompetency.cpp
cp ../../Projects/ProjectBrainweaver/pvdbcompetency.h temp_zip/Projects/ProjectBrainweaver/pvdbcompetency.h
cp ../../Projects/ProjectBrainweaver/pvdbconcept.cpp temp_zip/Projects/ProjectBrainweaver/pvdbconcept.cpp
cp ../../Projects/ProjectBrainweaver/pvdbconcept.h temp_zip/Projects/ProjectBrainweaver/pvdbconcept.h
cp ../../Projects/ProjectBrainweaver/pvdbconceptfactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbconceptfactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbconceptfactory.h temp_zip/Projects/ProjectBrainweaver/pvdbconceptfactory.h
cp ../../Projects/ProjectBrainweaver/pvdbconceptmap.cpp temp_zip/Projects/ProjectBrainweaver/pvdbconceptmap.cpp
cp ../../Projects/ProjectBrainweaver/pvdbconceptmap.h temp_zip/Projects/ProjectBrainweaver/pvdbconceptmap.h
cp ../../Projects/ProjectBrainweaver/pvdbconceptmapfactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbconceptmapfactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbconceptmapfactory.h temp_zip/Projects/ProjectBrainweaver/pvdbconceptmapfactory.h
cp ../../Projects/ProjectBrainweaver/pvdbedge.cpp temp_zip/Projects/ProjectBrainweaver/pvdbedge.cpp
cp ../../Projects/ProjectBrainweaver/pvdbedge.h temp_zip/Projects/ProjectBrainweaver/pvdbedge.h
cp ../../Projects/ProjectBrainweaver/pvdbedgefactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbedgefactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbedgefactory.h temp_zip/Projects/ProjectBrainweaver/pvdbedgefactory.h
cp ../../Projects/ProjectBrainweaver/pvdbexample.cpp temp_zip/Projects/ProjectBrainweaver/pvdbexample.cpp
cp ../../Projects/ProjectBrainweaver/pvdbexample.h temp_zip/Projects/ProjectBrainweaver/pvdbexample.h
cp ../../Projects/ProjectBrainweaver/pvdbexamplefactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbexamplefactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbexamplefactory.h temp_zip/Projects/ProjectBrainweaver/pvdbexamplefactory.h
cp ../../Projects/ProjectBrainweaver/pvdbexamples.cpp temp_zip/Projects/ProjectBrainweaver/pvdbexamples.cpp
cp ../../Projects/ProjectBrainweaver/pvdbexamples.h temp_zip/Projects/ProjectBrainweaver/pvdbexamples.h
cp ../../Projects/ProjectBrainweaver/pvdbexamplesfactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbexamplesfactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbexamplesfactory.h temp_zip/Projects/ProjectBrainweaver/pvdbexamplesfactory.h
cp ../../Projects/ProjectBrainweaver/pvdbfile.cpp temp_zip/Projects/ProjectBrainweaver/pvdbfile.cpp
cp ../../Projects/ProjectBrainweaver/pvdbfile.h temp_zip/Projects/ProjectBrainweaver/pvdbfile.h
cp ../../Projects/ProjectBrainweaver/pvdbfilefactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbfilefactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbfilefactory.h temp_zip/Projects/ProjectBrainweaver/pvdbfilefactory.h
cp ../../Projects/ProjectBrainweaver/pvdbfwd.h temp_zip/Projects/ProjectBrainweaver/pvdbfwd.h
cp ../../Projects/ProjectBrainweaver/pvdbhelper.cpp temp_zip/Projects/ProjectBrainweaver/pvdbhelper.cpp
cp ../../Projects/ProjectBrainweaver/pvdbhelper.h temp_zip/Projects/ProjectBrainweaver/pvdbhelper.h
cp ../../Projects/ProjectBrainweaver/pvdbmenudialog.cpp temp_zip/Projects/ProjectBrainweaver/pvdbmenudialog.cpp
cp ../../Projects/ProjectBrainweaver/pvdbmenudialog.h temp_zip/Projects/ProjectBrainweaver/pvdbmenudialog.h
cp ../../Projects/ProjectBrainweaver/pvdbnode.cpp temp_zip/Projects/ProjectBrainweaver/pvdbnode.cpp
cp ../../Projects/ProjectBrainweaver/pvdbnode.h temp_zip/Projects/ProjectBrainweaver/pvdbnode.h
cp ../../Projects/ProjectBrainweaver/pvdbnodefactory.cpp temp_zip/Projects/ProjectBrainweaver/pvdbnodefactory.cpp
cp ../../Projects/ProjectBrainweaver/pvdbnodefactory.h temp_zip/Projects/ProjectBrainweaver/pvdbnodefactory.h
cp ../../Projects/ProjectBrainweaver/pvdbrating.cpp temp_zip/Projects/ProjectBrainweaver/pvdbrating.cpp
cp ../../Projects/ProjectBrainweaver/pvdbrating.h temp_zip/Projects/ProjectBrainweaver/pvdbrating.h
cp ../../Projects/ProjectBrainweaver/qtmain_assessor.cpp temp_zip/Projects/ProjectBrainweaver/qtmain_assessor.cpp
cp ../../Projects/ProjectBrainweaver/qtmain_developer.cpp temp_zip/Projects/ProjectBrainweaver/qtmain_developer.cpp
cp ../../Projects/ProjectBrainweaver/qtmain_student.cpp temp_zip/Projects/ProjectBrainweaver/qtmain_student.cpp
cp ../../Projects/ProjectBrainweaver/qtmain_testconceptmap.cpp temp_zip/Projects/ProjectBrainweaver/qtmain_testconceptmap.cpp
cp ../../Projects/ProjectBrainweaver/qtmainassessor.cpp temp_zip/Projects/ProjectBrainweaver/qtmainassessor.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbaboutdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbaboutdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbaboutdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbaboutdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbassessormenudialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbassessormenudialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbassessormenudialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbassessormenudialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbassessormenudialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbassessormenudialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbbrushfactory.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbbrushfactory.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbbrushfactory.h temp_zip/Projects/ProjectBrainweaver/qtpvdbbrushfactory.h
cp ../../Projects/ProjectBrainweaver/qtpvdbcenternodeitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbcenternodeitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbcenternodeitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbcenternodeitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbclusterdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbclusterdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbclusterdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbclusterdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbclusterdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbclusterdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbclusterwidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbclusterwidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbclusterwidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdbclusterwidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbcompetency.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbcompetency.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbcompetency.h temp_zip/Projects/ProjectBrainweaver/qtpvdbcompetency.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconcepteditdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconcepteditdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconcepteditdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconcepteditdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconcepteditdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbconcepteditdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapdesignerwidget.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapdesignerwidget.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapdisplaywidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapdisplaywidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapdisplaywidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapdisplaywidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapeditwidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapeditwidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapeditwidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapeditwidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapratewidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapratewidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapratewidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapratewidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapwidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapwidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbconceptmapwidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdbconceptmapwidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentcompletedialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentcompletedialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentcompletedialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentcompletedialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentcompletedialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentcompletedialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentmenudialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentmenudialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentmenudialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentmenudialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentmenudialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentmenudialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentpartialdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentpartialdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentpartialdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentpartialdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbcreateassessmentpartialdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbcreateassessmentpartialdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbdisplay.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbdisplay.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbdisplay.h temp_zip/Projects/ProjectBrainweaver/qtpvdbdisplay.h
cp ../../Projects/ProjectBrainweaver/qtpvdbdisplayconceptitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbdisplayconceptitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbdisplayconceptitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbdisplayconceptitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbedgeitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbedgeitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbedgeitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbedgeitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbeditconceptitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbeditconceptitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbeditconceptitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbeditconceptitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbexamplesitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbexamplesitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbexamplesitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbexamplesitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbitemhighlighter.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbitemhighlighter.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbitemhighlighter.h temp_zip/Projects/ProjectBrainweaver/qtpvdbitemhighlighter.h
cp ../../Projects/ProjectBrainweaver/qtpvdbmenudialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbmenudialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbmenudialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbmenudialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbmenudialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbmenudialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbnewarrow.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbnewarrow.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbnewarrow.h temp_zip/Projects/ProjectBrainweaver/qtpvdbnewarrow.h
cp ../../Projects/ProjectBrainweaver/qtpvdbnodeitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbnodeitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbnodeitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbnodeitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdboverviewdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdboverviewdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdboverviewdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdboverviewdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdboverviewwidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdboverviewwidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdboverviewwidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdboverviewwidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbprintconceptmapdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbprintconceptmapdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbprintconceptmapdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbprintconceptmapdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbprintconceptmapdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbprintconceptmapdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbprintratingdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbprintratingdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbprintratingdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbprintratingdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbprintratingdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbprintratingdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptautodialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptautodialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptautodialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptautodialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptautodialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptautodialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptmapdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptmapdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptmapdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptmapdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbrateconceptmapdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbrateconceptmapdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbratedconceptwidget.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbratedconceptwidget.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbratedconceptwidget.h temp_zip/Projects/ProjectBrainweaver/qtpvdbratedconceptwidget.h
cp ../../Projects/ProjectBrainweaver/qtpvdbratedconceptwidget.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbratedconceptwidget.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbrateexamplesdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbrateexamplesdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbrateexamplesdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbrateexamplesdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbrateexamplesdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbrateexamplesdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbratingdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbratingdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbratingdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbratingdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbratingdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbratingdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbstudentmenudialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbstudentmenudialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbstudentmenudialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbstudentmenudialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbstudentmenudialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbstudentmenudialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbstudentstartcompletedialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbstudentstartcompletedialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbstudentstartcompletedialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbstudentstartcompletedialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbstudentstartcompletedialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbstudentstartcompletedialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptitemdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptitemdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptitemdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptitemdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptitemdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptitemdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapdisplaywidgetdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapdisplaywidgetdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapdisplaywidgetdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapdisplaywidgetdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapdisplaywidgetdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapdisplaywidgetdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapeditwidgetdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapeditwidgetdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapeditwidgetdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapeditwidgetdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapeditwidgetdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapeditwidgetdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapratewidgetdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapratewidgetdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapratewidgetdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapratewidgetdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestconceptmapratewidgetdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestconceptmapratewidgetdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestcreatesubconceptmapdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestcreatesubconceptmapdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestcreatesubconceptmapdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestcreatesubconceptmapdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestcreatesubconceptmapdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestcreatesubconceptmapdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestedgeitemdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestedgeitemdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestedgeitemdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestedgeitemdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestedgeitemdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestedgeitemdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtestnodeitemdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtestnodeitemdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtestnodeitemdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtestnodeitemdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbtestnodeitemdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbtestnodeitemdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbtoolsitem.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbtoolsitem.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbtoolsitem.h temp_zip/Projects/ProjectBrainweaver/qtpvdbtoolsitem.h
cp ../../Projects/ProjectBrainweaver/qtpvdbviewfilesdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbviewfilesdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbviewfilesdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbviewfilesdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbviewfilesdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbviewfilesdialog.ui
cp ../../Projects/ProjectBrainweaver/qtpvdbviewtestsdialog.cpp temp_zip/Projects/ProjectBrainweaver/qtpvdbviewtestsdialog.cpp
cp ../../Projects/ProjectBrainweaver/qtpvdbviewtestsdialog.h temp_zip/Projects/ProjectBrainweaver/qtpvdbviewtestsdialog.h
cp ../../Projects/ProjectBrainweaver/qtpvdbviewtestsdialog.ui temp_zip/Projects/ProjectBrainweaver/qtpvdbviewtestsdialog.ui
cp ../../Projects/ProjectBrainweaver/sloccount.sh temp_zip/Projects/ProjectBrainweaver/sloccount.sh
cp ../../Projects/ProjectBrainweaver/test_pvdbcluster.cpp temp_zip/Projects/ProjectBrainweaver/test_pvdbcluster.cpp
cp ../../Projects/ProjectBrainweaver/test_pvdbconcept.cpp temp_zip/Projects/ProjectBrainweaver/test_pvdbconcept.cpp
cp ../../Projects/ProjectBrainweaver/test_pvdbconceptmap.cpp temp_zip/Projects/ProjectBrainweaver/test_pvdbconceptmap.cpp
cp ../../Projects/ProjectBrainweaver/test_qtpvdbconceptmapdialog.cpp temp_zip/Projects/ProjectBrainweaver/test_qtpvdbconceptmapdialog.cpp
cp ../../Projects/ProjectBrainweaver/test_qtpvdbconceptmapeditwidget.cpp temp_zip/Projects/ProjectBrainweaver/test_qtpvdbconceptmapeditwidget.cpp
cp ../../Projects/ProjectBrainweaver/test_qtpvdbconceptmapratewidget.cpp temp_zip/Projects/ProjectBrainweaver/test_qtpvdbconceptmapratewidget.cpp
cp ../../Projects/ProjectBrainweaver/test_qtpvdbconceptmapwidget.cpp temp_zip/Projects/ProjectBrainweaver/test_qtpvdbconceptmapwidget.cpp
cp ../../Projects/ProjectBrainweaver/zip.sh temp_zip/Projects/ProjectBrainweaver/zip.sh
cp ../../Projects/ProjectBrainweaver/zip.sh~ temp_zip/Projects/ProjectBrainweaver/zip.sh~
cp ../../Projects/ProjectBrainweaver/zipexes.sh temp_zip/Projects/ProjectBrainweaver/zipexes.sh
cp ../../Projects/ProjectBrainweaver/zipexes.sh~ temp_zip/Projects/ProjectBrainweaver/zipexes.sh~
cp ../../Tools/ToolStyleSheetSetter/R.png temp_zip/Tools/ToolStyleSheetSetter/R.png
cp ../../Tools/ToolStyleSheetSetter/ToolStyleSheetSetter.qrc temp_zip/Tools/ToolStyleSheetSetter/ToolStyleSheetSetter.qrc
cp ../../Tools/ToolStyleSheetSetter/toolstylesheetsettermaindialog.cpp temp_zip/Tools/ToolStyleSheetSetter/toolstylesheetsettermaindialog.cpp
cp ../../Tools/ToolStyleSheetSetter/toolstylesheetsettermaindialog.h temp_zip/Tools/ToolStyleSheetSetter/toolstylesheetsettermaindialog.h
cp ../../Tools/ToolStyleSheetSetter/toolstylesheetsettermaindialog.ui temp_zip/Tools/ToolStyleSheetSetter/toolstylesheetsettermaindialog.ui
cp ../../Tools/ToolTestQtArrowItems/Licence.txt temp_zip/Tools/ToolTestQtArrowItems/Licence.txt
cp ../../Tools/ToolTestQtArrowItems/R.png temp_zip/Tools/ToolTestQtArrowItems/R.png
cp ../../Tools/ToolTestQtArrowItems/ToolTestQtArrowItems.png temp_zip/Tools/ToolTestQtArrowItems/ToolTestQtArrowItems.png
cp ../../Tools/ToolTestQtArrowItems/ToolTestQtArrowItems.qrc temp_zip/Tools/ToolTestQtArrowItems/ToolTestQtArrowItems.qrc
cp ../../Tools/ToolTestQtArrowItems/crosscompiletowindows.sh temp_zip/Tools/ToolTestQtArrowItems/crosscompiletowindows.sh
cp ../../Tools/ToolTestQtArrowItems/qttestqtarrowitemsmaindialog.cpp temp_zip/Tools/ToolTestQtArrowItems/qttestqtarrowitemsmaindialog.cpp
cp ../../Tools/ToolTestQtArrowItems/qttestqtarrowitemsmaindialog.h temp_zip/Tools/ToolTestQtArrowItems/qttestqtarrowitemsmaindialog.h
cp ../../Tools/ToolTestQtArrowItems/qttestqtarrowitemsmaindialog.ui temp_zip/Tools/ToolTestQtArrowItems/qttestqtarrowitemsmaindialog.ui
cp ../../Tools/ToolTestQtArrowItems/qttestqtarrowitemsmenudialog.cpp temp_zip/Tools/ToolTestQtArrowItems/qttestqtarrowitemsmenudialog.cpp
cp ../../Tools/ToolTestQtArrowItems/qttestqtarrowitemsmenudialog.h temp_zip/Tools/ToolTestQtArrowItems/qttestqtarrowitemsmenudialog.h
cp ../../Tools/ToolTestQtArrowItems/qttestqtarrowitemsmenudialog.ui temp_zip/Tools/ToolTestQtArrowItems/qttestqtarrowitemsmenudialog.ui
cp ../../Tools/ToolTestQtArrowItems/testqtarrowitemsmenudialog.cpp temp_zip/Tools/ToolTestQtArrowItems/testqtarrowitemsmenudialog.cpp
cp ../../Tools/ToolTestQtArrowItems/testqtarrowitemsmenudialog.h temp_zip/Tools/ToolTestQtArrowItems/testqtarrowitemsmenudialog.h
cp ../../Tools/ToolTestQtRoundedEditRectItem/Licence.txt temp_zip/Tools/ToolTestQtRoundedEditRectItem/Licence.txt
cp ../../Tools/ToolTestQtRoundedEditRectItem/R.png temp_zip/Tools/ToolTestQtRoundedEditRectItem/R.png
cp ../../Tools/ToolTestQtRoundedEditRectItem/ToolTestQtRoundedEditRectItem.qrc temp_zip/Tools/ToolTestQtRoundedEditRectItem/ToolTestQtRoundedEditRectItem.qrc
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmaindialog.cpp temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmaindialog.cpp
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmaindialog.h temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmaindialog.h
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmaindialog.ui temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmaindialog.ui
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmenudialog.cpp temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmenudialog.cpp
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmenudialog.h temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmenudialog.h
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmenudialog.ui temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemmenudialog.ui
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemwidget.cpp temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemwidget.cpp
cp ../../Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemwidget.h temp_zip/Tools/ToolTestQtRoundedEditRectItem/qttestqtroundededitrectitemwidget.h
cp ../../Tools/ToolTestQtRoundedEditRectItem/testqtroundededitrectitemmenudialog.cpp temp_zip/Tools/ToolTestQtRoundedEditRectItem/testqtroundededitrectitemmenudialog.cpp
cp ../../Tools/ToolTestQtRoundedEditRectItem/testqtroundededitrectitemmenudialog.h temp_zip/Tools/ToolTestQtRoundedEditRectItem/testqtroundededitrectitemmenudialog.h
cp ../../Tools/ToolTestQtRoundedTextRectItem/Licence.txt temp_zip/Tools/ToolTestQtRoundedTextRectItem/Licence.txt
cp ../../Tools/ToolTestQtRoundedTextRectItem/R.png temp_zip/Tools/ToolTestQtRoundedTextRectItem/R.png
cp ../../Tools/ToolTestQtRoundedTextRectItem/ToolTestQtRoundedTextRectItem.png temp_zip/Tools/ToolTestQtRoundedTextRectItem/ToolTestQtRoundedTextRectItem.png
cp ../../Tools/ToolTestQtRoundedTextRectItem/ToolTestQtRoundedTextRectItem.qrc temp_zip/Tools/ToolTestQtRoundedTextRectItem/ToolTestQtRoundedTextRectItem.qrc
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmaindialog.cpp temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmaindialog.cpp
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmaindialog.h temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmaindialog.h
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmaindialog.ui temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmaindialog.ui
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmenudialog.cpp temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmenudialog.cpp
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmenudialog.h temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmenudialog.h
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmenudialog.ui temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemmenudialog.ui
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemwidget.cpp temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemwidget.cpp
cp ../../Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemwidget.h temp_zip/Tools/ToolTestQtRoundedTextRectItem/qttestqtroundedtextrectitemwidget.h
cp ../../Tools/ToolTestQtRoundedTextRectItem/testqtroundedtextrectitemmenudialog.cpp temp_zip/Tools/ToolTestQtRoundedTextRectItem/testqtroundedtextrectitemmenudialog.cpp
cp ../../Tools/ToolTestQtRoundedTextRectItem/testqtroundedtextrectitemmenudialog.h temp_zip/Tools/ToolTestQtRoundedTextRectItem/testqtroundedtextrectitemmenudialog.h

FILENAME="ProjectBrainweaverSource"
ZIP_FILENAME=$FILENAME".zip"

echo "Compressing files"

cd temp_zip
zip -r $FILENAME Classes
zip -r $FILENAME Projects
zip -r $FILENAME Tools
cd ..
cp "temp_zip/"$ZIP_FILENAME $ZIP_FILENAME

echo "Cleaning up"

echo "Emptying subfolders"

rm temp_zip/Classes/CppAbout/*.*
rm temp_zip/Classes/CppFuzzy_equal_to/*.*
rm temp_zip/Classes/CppLazy_init/*.*
rm temp_zip/Classes/CppQtAboutDialog/*.*
rm temp_zip/Classes/CppQtArrowItem/*.*
rm temp_zip/Classes/CppQtHideAndShowDialog/*.*
rm temp_zip/Classes/CppQtKeyboardFriendlyGraphicsView/*.*
rm temp_zip/Classes/CppQtLabeledQuadBezierArrowItem/*.*
rm temp_zip/Classes/CppQtPathArrowItem/*.*
rm temp_zip/Classes/CppQtQuadBezierArrowItem/*.*
rm temp_zip/Classes/CppQtRoundedEditRectItem/*.*
rm temp_zip/Classes/CppQtRoundedRectItem/*.*
rm temp_zip/Classes/CppQtRoundedTextRectItem/*.*
rm temp_zip/Classes/CppQtScopedDisable/*.*
rm temp_zip/Classes/CppTrace/*.*
rm temp_zip/Projects/ProjectBrainweaver/*.*
rm temp_zip/Tools/ToolStyleSheetSetter/*.*
rm temp_zip/Tools/ToolTestQtArrowItems/*.*
rm temp_zip/Tools/ToolTestQtRoundedEditRectItem/*.*
rm temp_zip/Tools/ToolTestQtRoundedTextRectItem/*.*

echo "Removing subfolders"

rmdir temp_zip/Classes/CppAbout
rmdir temp_zip/Classes/CppFuzzy_equal_to
rmdir temp_zip/Classes/CppLazy_init
rmdir temp_zip/Classes/CppQtAboutDialog
rmdir temp_zip/Classes/CppQtArrowItem
rmdir temp_zip/Classes/CppQtHideAndShowDialog
rmdir temp_zip/Classes/CppQtKeyboardFriendlyGraphicsView
rmdir temp_zip/Classes/CppQtLabeledQuadBezierArrowItem
rmdir temp_zip/Classes/CppQtPathArrowItem
rmdir temp_zip/Classes/CppQtQuadBezierArrowItem
rmdir temp_zip/Classes/CppQtRoundedEditRectItem
rmdir temp_zip/Classes/CppQtRoundedRectItem
rmdir temp_zip/Classes/CppQtRoundedTextRectItem
rmdir temp_zip/Classes/CppQtScopedDisable
rmdir temp_zip/Classes/CppTrace
rmdir temp_zip/Projects/ProjectBrainweaver
rmdir temp_zip/Tools/ToolStyleSheetSetter
rmdir temp_zip/Tools/ToolTestQtArrowItems
rmdir temp_zip/Tools/ToolTestQtRoundedEditRectItem
rmdir temp_zip/Tools/ToolTestQtRoundedTextRectItem

echo "Removing main folders"

rmdir temp_zip/Classes
rmdir temp_zip/Projects
rmdir temp_zip/Tools

echo "Removing temporary folder"

rm temp_zip/*.*
rmdir temp_zip

echo "Done"

# CreateQtProjectZipFile, version 1.3
# Copyright (C) 2012 Richel Bilderbeek
# Programmed on the 10th of June 2012
# by Richel Bilderbeek
# 
# CreateQtProjectZipFile can be downloaded from http://www.richelbilderbeek.nl/ToolCreateQtProjectZipFile.htm
# Licenced under GPL 3.0
