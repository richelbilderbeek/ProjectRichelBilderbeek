#ifndef QTPVDBRATECONCEPTAUTODIALOG_H
#define QTPVDBRATECONCEPTAUTODIALOG_H

#include <boost/shared_ptr.hpp>
#include "qthideandshowdialog.h"
#include "pvdbfwd.h"

namespace Ui {
  class QtPvdbRateConceptAutoDialog;
}

class QtPvdbRateConceptAutoDialog : public QtHideAndShowDialog
{
  Q_OBJECT
  
public:
  explicit QtPvdbRateConceptAutoDialog(
    const boost::shared_ptr<pvdb::ConceptMap> sub_concept_map,
    QWidget *parent = 0);
  ~QtPvdbRateConceptAutoDialog();
  
  ///Obtain the suggested complexity, calculated from this dialog
  int GetSuggestedComplexity() const;

  ///Obtain the suggested concreteness, calculated from this dialog
  int GetSuggestedConcreteness() const;

  ///Obtain the suggested specificity, calculated from this dialog
  int GetSuggestedSpecificity() const;

protected:
  void keyPressEvent(QKeyEvent *);
  //void resizeEvent(QResizeEvent *);
  //void showEvent(QShowEvent *);
private:
  Ui::QtPvdbRateConceptAutoDialog *ui;
};

#endif // QTPVDBRATECONCEPTAUTODIALOG_H
