#include <iostream>

int main()
{
  const auto s = "Hello C++11";
  std::cout << s << '\n';
}
